@include('admin.include.header')
@include('admin.include.sidebar')
@yield('content')

@include('admin.include.footer')