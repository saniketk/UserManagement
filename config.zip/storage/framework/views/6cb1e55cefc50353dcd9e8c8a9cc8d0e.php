
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card p-4">
        <h4>Registered Users</h4>
            <hr>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th> #</th>
                        <th> Full Name</th>
                        <th> Email</th>
                        <th> Date of Birth</th>
                        <th> Gender</th>
                        <th> Country</th>
                        <th> State</th>
                        <th> City</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $srno = 0; ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $srno++; ?>
                        <tr>
                            <td> <?php echo e($srno); ?> </td>    
                            <td> <?php echo e($user['full_name']); ?> </td>    
                            <td> <?php echo e($user['email']); ?> </td>    
                            <td> <?php echo e(\Carbon\Carbon::parse($user->dob)->format('d M Y')); ?> </td>    
                            <td> <?php echo e($user['gender']); ?> </td>    
                            <td><?php echo e($user->country ? $user->country->country_name : 'N/A'); ?> </td>    
                            <td><?php echo e($user->state ? $user->state->state_name : 'N/A'); ?> </td>    
                            <td><?php echo e($user->city ? $user->city->city_name : 'N/A'); ?> </td>    
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2025\userManagement\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>